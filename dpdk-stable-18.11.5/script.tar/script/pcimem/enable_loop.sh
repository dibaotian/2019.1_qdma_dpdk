
user_pf="/sys/devices/pci0000\:d8/0000\:d8\:00.0/0000\:d9\:00.0/resource2"
sudo ./pcimem-master/pcimem ${user_pf} 0x00110204 w
sudo ./pcimem-master/pcimem ${user_pf} 0x00100014 w 0x01
sudo ./pcimem-master/pcimem ${user_pf} 0x0010000C w 0x10
sudo ./pcimem-master/pcimem ${user_pf} 0x00100204 w
sudo ./pcimem-master/pcimem ${user_pf} 0x0010000C w 0x01
sudo ./pcimem-master/pcimem ${user_pf} 0x00100204 w

